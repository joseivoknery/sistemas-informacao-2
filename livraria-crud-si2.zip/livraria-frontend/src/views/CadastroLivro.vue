<template>
  <div class="cadastro">
    <CadastrarLivro />
    <br />
  </div>
</template>

<script>
import CadastrarLivro from "@/components/CadastrarLivro.vue";

export default {
  name: "CadastroLivro",
  components: {
    CadastrarLivro
  }
};
</script>
