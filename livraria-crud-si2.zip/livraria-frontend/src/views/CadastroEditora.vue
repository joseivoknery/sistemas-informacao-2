<template>
  <div class="cadastro">
    <CadastrarEditora />
    <br />
  </div>
</template>

<script>
import CadastrarEditora from "@/components/CadastrarEditora.vue";

export default {
  name: "CadastroEditora",
  components: {
    CadastrarEditora
  }
};
</script>
