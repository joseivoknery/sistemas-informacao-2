<template>
  <div class="about">
    <Apresentacao />
  </div>
</template>

<script>
import Apresentacao from "@/components/Apresentacao.vue";

export default {
  name: "About",
  components: {
    Apresentacao
  }
};
</script>
