<template>
  <div class="home">
    <ListarEditoras />
    <br />
  </div>
</template>

<script>
import ListarEditoras from "@/components/ListarEditoras.vue";

export default {
  name: "ListaDeEditoras",
  components: {
    ListarEditoras
  }
};
</script>
