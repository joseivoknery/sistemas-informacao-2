package br.com.api.backend.livros;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LivrosBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(LivrosBackendApplication.class, args);
	}

}
