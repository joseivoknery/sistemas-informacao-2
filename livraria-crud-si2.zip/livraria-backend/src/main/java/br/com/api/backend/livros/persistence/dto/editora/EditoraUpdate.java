/**
 *
 */
package br.com.api.backend.livros.persistence.dto.editora;

/**
 * @author José Ivo K. Nery
 *
 */
public class EditoraUpdate {

  private String nomeEditora;

  public String getNomeEditora() {
    return this.nomeEditora;
  }

  public void setNomeEditora(String nomeEditora) {
    this.nomeEditora = nomeEditora;
  }

}
